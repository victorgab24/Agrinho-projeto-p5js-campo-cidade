let produtos = [];
let carros = [];
let campo = [];
let arvores = [];
let edificios = [];

function setup() {
  createCanvas(800, 400);
  
  // Inicializar produtos
  for (let i = 0; i < 5; i++) {
    produtos.push(new Produto(100, random(50, 350)));
  }

  // Inicializar carros
  for (let i = 0; i < 3; i++) {
    carros.push(new Carro(600 + random(50, 150), random(350, 380)));
  }

  // Inicializar árvores no campo
  for (let i = 0; i < 5; i++) {
    arvores.push(new Arvore(random(150, 350), random(100, 300)));
  }

  // Inicializar campo de agricultura
  for (let i = 0; i < 10; i++) {
    campo.push(new LinhaCultivo(i * 60 + 150, random(200, 350)));
  }

  // Inicializar prédios na cidade
  for (let i = 0; i < 5; i++) {
    edificios.push(new Edificio(600 + i * 60, height - 120));
  }
}

function draw() {
  background(220);

  // Metade esquerda - Campo de Agricultura
  fill(34, 139, 34); // Verde para o campo
  rect(0, 0, 400, height);
  fill(255);
  textSize(24);
  textAlign(CENTER, TOP);
  text("Campo de Agricultura", 200, 20);

  // Mostrar campo de cultivo (linhas de plantio)
  for (let c of campo) {
    c.show();
  }

  // Mostrar árvores no campo
  for (let t of arvores) {
    t.show();
  }

  // Mostrar produtos
  for (let p of produtos) {
    p.show();
    p.update();
  }

  // Metade direita - Carros e Prédios na cidade
  fill(169, 169, 169); // Cinza para a estrada
  rect(400, 0, width - 400, height);
  fill(255);
  text("Cidade", 600, 20);

  // Mostrar carros na estrada
  for (let c of carros) {
    c.show();
    c.update();
  }

  // Mostrar prédios na cidade
  for (let e of edificios) {
    e.show();
  }

  // Linha de divisão entre campo e cidade
  stroke(0);
  line(400, 0, 400, height);
}

// Classe Produto (representa um produto agrícola)
class Produto {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 20;
    this.speed = random(2, 4);
  }

  show() {
    fill(255, 204, 0); // Amarelo (fruta ou vegetal)
    ellipse(this.x, this.y, this.size, this.size);
  }

  update() {
    if (this.x < 400) {
      this.x += this.speed; // Movimento para a cidade
    } else {
      // Ao atingir a cidade, resetamos o produto para o campo
      this.x = 100;
      this.y = random(50, 350);
    }
  }
}

// Classe Carro (representa um carro mais realista na estrada)
class Carro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 40;
    this.speed = random(1, 2);
  }

  show() {
    // Corpo do carro
    fill(255, 0, 0); // Carro vermelho
    rect(this.x, this.y, this.size, 20, 5); // Carro com bordas arredondadas

    // Rodas
    fill(0); // Rodas pretas
    ellipse(this.x + 10, this.y + 20, 10, 10); // Roda esquerda
    ellipse(this.x + 30, this.y + 20, 10, 10); // Roda direita

    // Janelas
    fill(255, 255, 255, 150); // Vidros translúcidos
    rect(this.x + 5, this.y + 5, 10, 8); // Janela da esquerda
    rect(this.x + 25, this.y + 5, 10, 8); // Janela da direita
  }

  update() {
    this.x -= this.speed;
    if (this.x < 400) {
      this.x = 600 + random(50, 150); // Resetando a posição do carro
    }
  }
}

// Classe Arvore (representa uma árvore no campo)
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  show() {
    fill(139, 69, 19); // Tronco da árvore
    rect(this.x - 5, this.y, 10, 30); // Tronco
    fill(34, 139, 34); // Folhas
    ellipse(this.x, this.y - 15, 40, 40); // Folhas
  }
}

// Classe LinhaCultivo (representa uma linha de plantio)
class LinhaCultivo {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  show() {
    stroke(139, 69, 19); // Cor marrom para as linhas de cultivo
    line(this.x, this.y, this.x + 40, this.y); // Linhas de cultivo horizontais
  }
}

// Classe Edificio (representa um prédio na cidade)
class Edificio {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.width = 50;
    this.height = random(100, 200); // Altura aleatória para os prédios
    this.color = color(random(150, 255), random(150, 255), random(150, 255)); // Cor aleatória para o prédio
  }

  show() {
    fill(this.color); // Cor do prédio
    rect(this.x, this.y - this.height, this.width, this.height); // Corpo do prédio

    // Janela
    fill(0);
    for (let j = this.y - this.height + 20; j < this.y; j += 30) {
      for (let i = this.x + 10; i < this.x + this.width - 10; i += 20) {
        rect(i, j, 15, 15); // Criando janelas
      }
    }
  }
}
